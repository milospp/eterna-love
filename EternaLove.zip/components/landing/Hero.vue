<template>
    <div class="mx-auto gap-5 max-w-7xl sm:flex pt-20 pb-10">
        <div class="sm:w-1/2 md:w-1/2">
            <div class="flex flex-col justify-center h-full">
                <h1 class=" text-5xl md:text-6xl font-bold mt-10 mb-10 pl-16 pr-10">Vizualizujte vaš chat</h1>
                <SharedCtaButton class="hidden sm:flex"></SharedCtaButton>
            </div>
        </div>
        <div class="md:w-1/2 sm:w-1/2">
            <div class="flex items-end justify-center relative h-full">
                <div class="relative border-8 w-1/2 border-gray-700 z-20 shadow-lg">
                    <div class="poster-shadow"></div>
                    <img class="relative z-10" src="public/EternaExample1.png" alt="">
                </div>
                <div class="relative border-8 w-2/5 border-gray-700 ml-[-10%] mb-1 z-10 shadow-sm">
                    <div class="poster-shadow"></div>
                    <img class="relative z-20" src="public/EternaExample1.png" alt="">
                </div>
            </div>
            <SharedCtaButton class="sm:hidden"></SharedCtaButton>
        </div>
    </div>
</template>

<script lang="ts" setup>

</script>

<style scoped>
.poster-shadow {
    content: '';
    position: absolute;
    left: -10px;
    right: -10px;
    bottom: -20px;
    background: rgba(0, 0, 0, 0.5);
    z-index: 1;
    height: 29px;
    border-radius: 100%;
    filter: blur(10px);
}
</style>