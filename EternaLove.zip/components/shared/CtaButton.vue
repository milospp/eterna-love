<template>
    <button
        class="bg-yellow-300 hover:bg-yellow-400 mx-auto rounded-full text-black p-5 px-8 shadow-lg flex items-center justify-between gap-5 my-10">
        <span>Generiši svoj poster</span>
        <svg width="8" height="12" viewBox="0 0 8 12" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd"
                d="M4.47264 6.12504L0.626831 2.27924L2.27851 0.627563L7.77598 6.12504L2.27851 11.6225L0.626831 9.97085L4.47264 6.12504Z"
                fill="#0D0A39" />
        </svg>

    </button>
</template>

<script setup>

</script>

<style scoped></style>