<template>
    <div>
        <div class="relative">
            <div class="relative z-10">
                <CoreNavbar />
                <LandingHero />
            </div>
            <LandingGradientGoo class="absolute top-0 z-0 h-full" />
        </div>
        <LandingItems />

        <LandingFeatures />
        <LandingFaq />
        <LandingFooter />
    </div>
</template>