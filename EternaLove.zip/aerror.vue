<template>
    <div class="text-lg">
        ERRROR
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>